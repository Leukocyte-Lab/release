#!/usr/bin/env bash
# shellcheck disable=SC2034

load_bashrc() {
  if [ -f "$HOME/.bashrc" ]; then
    # shellcheck disable=SC1091
    source "$HOME/.bashrc"
  fi
}

load_vm_info() {
  if [ -f "$HOME/.vmrc" ]; then
    # shellcheck disable=SC1091
    source "$HOME/.vmrc"
  elif [ -f "$DIR_PATH/.vmrc" ]; then
    # shellcheck disable=SC1091
    source "$DIR_PATH/.vmrc"
  fi

  if [[ -n "$VM_TYPE" ]]; then
    declare -A VM_NAME_MAP
    VM_NAME_MAP["CTR3_PLAYER"]="${BRAND}3 CTR Player"
    VM_NAME_MAP["C2_AGENT_SERVER"]="${BRAND} C2 Agent Server"
    VM_NAME_MAP["SYSTEM_AGENT_SERVER"]="${BRAND} System Agent Server"

    if command -v kubectl >/dev/null 2>&1; then
      SYSTEM_VERSION="$(kubectl -n "$NAMESPACE" get deploy/captain -o=jsonpath='{.spec.template.spec.containers[?(@.name=="captain")].env[?(@.name=="APP_VERSION")].value}')"
    fi

    declare -A VM_SUPPORT_MODULE_MAP
    if [[ -n "$SYSTEM_VERSION" ]] && version_lt "$SYSTEM_VERSION" "v3.10.0"; then
      VM_SUPPORT_MODULE_MAP["CTR3_PLAYER"]="ip proxy backup restore bind-ip benchmark check-network first-aid user-mgr system-upgrade update version help"
    else
      # Hidden module
      # shellcheck disable=SC1091
      source "$DIR_PATH/modules/system-upgrade/main.sh"
      VM_SUPPORT_MODULE_MAP["CTR3_PLAYER"]="ip proxy backup restore bind-ip benchmark check-network first-aid user-mgr update version help"
    fi

    VM_SUPPORT_MODULE_MAP["C2_AGENT_SERVER"]="ip benchmark update version help"
    VM_SUPPORT_MODULE_MAP["SYSTEM_AGENT_SERVER"]="ip benchmark update version help"

    VM_NAME="${VM_NAME_MAP[$VM_TYPE]}"
    VM_SUPPORT_MODULES="${VM_SUPPORT_MODULE_MAP[$VM_TYPE]}"
  else
    UNSUPPORTED=true
  fi
}

load_module() {
  # Load basic modules
  if [ -d "$DIR_PATH/modules/_" ]; then
    # shellcheck disable=SC1090
    source "$DIR_PATH/modules/_"/*.sh
  fi

  # shellcheck disable=SC2206
  MODULES=($VM_SUPPORT_MODULES)
  INSTALLED_MODULES=()
  if [[ -n "$VM_SUPPORT_MODULES" ]] ; then
    for module in "${MODULES[@]}"; do
      if [ -f "$DIR_PATH/modules/$module/main.sh" ]; then
        # shellcheck disable=SC1090
        source "$DIR_PATH/modules/$module/main.sh"
        INSTALLED_MODULES+=("$module")
      fi
    done
  fi
}
