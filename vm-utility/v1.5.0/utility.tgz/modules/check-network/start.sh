#!/bin/bash

check-ping () {
  target="$1";
  ping -c 1 "$target" 2> \
    >(sed $'s/.*/\033[30;41m FAILED \033[m \033[31m&\033[m/'>&2) \
    | grep 'PING' | awk '{print $3}' | sed -E 's/\(|\)//g' \
    | awk -v target="$target" '{ printf "\033[30;42m SUCCESS \033[m \033[32m%s:\t%s\033[m\n", target, $1 }'
}

log info "Starting network test..."

check-ping "$LICENSE_SERVER";
check-ping "$REGISTRY_SERVER";
check-ping "$RELEASE_CHANNEL_SERVER";
check-ping "$ARTIFACT_SERVER";
check-ping "$POINT_SYS_SERVER";
check-ping "$CHART_SERVER";

echo -ne "$(log info "Checking connection to") $(color "$LICENSE_SERVER\0" "fg-cyan")... \t "
response=$(curl -s -o /dev/null -w "%{http_code}" "https://$LICENSE_SERVER/v1/ping")
if [ "$response" == "200" ]; then
    color "[ OK ]" "bold fg-green"
else
    color "[ FAILED ]" "bold fg-red"
    log error "Unexpected response code: $response"
fi

echo -ne "$(log info "Checking connection to") $(color "$REGISTRY_SERVER" "fg-cyan")... \t "
response=$(curl --connect-timeout 10 -s "https://$REGISTRY_SERVER/api/v2.0/ping")
if [ "$response" == "Pong" ]; then
    color "[ OK ]" "bold fg-green"
else
    color "[ FAILED ]" "bold fg-red"
    log error "Unexpected response: $response"
fi

echo -ne "$(log info "Checking connection to") $(color "$RELEASE_CHANNEL_SERVER" "fg-cyan")... \t "
response=$(curl --connect-timeout 10 -s "https://$RELEASE_CHANNEL_SERVER/dev/version.yaml")
if [[ "$response" == *"timestamp"* ]]; then
    color "[ OK ]" "bold fg-green"
else
    color "[ FAILED ]" "bold fg-red"
    log error "Unexpected response: $response"
fi

echo -ne "$(log info "Checking connection to") $(color "$ARTIFACT_SERVER" "fg-cyan")... \t "
response=$(curl --connect-timeout 10 -s "https://$ARTIFACT_SERVER")
if [[ "$response" == *"<?xml version='1.0' encoding='UTF-8'?><Error><Code>AccessDenied</Code><Message>Access denied.</Message></Error>"* ]]; then
    color "[ OK ]" "bold fg-green"
else
    color "[ FAILED ]" "bold fg-red"
    log error "Unexpected response: $response"
fi

echo -ne "$(log info "Checking connection to") $(color "$POINT_SYS_SERVER" "fg-cyan")...\t"
response=$(curl --connect-timeout 10 -s -o /dev/null -w "%{http_code}"  "https://$POINT_SYS_SERVER")
if [[ "$response" == *"200"* ]]; then
    color "[ OK ]" "bold fg-green"
else
    color "[ FAILED ]" "bold fg-red"
    log error "Unexpected response: $response"
fi

echo -ne "$(log info "Checking connection to") $(color "$CHART_SERVER" "fg-cyan")...\t"
response=$(curl --connect-timeout 10 -s "https://$CHART_SERVER/index.yaml")
if [[ "$response" == *"apiVersion"* ]]; then
    color "[ OK ]" "bold fg-green"
else
    color "[ FAILED ]" "bold fg-red"
    log error "Unexpected response: $response"
fi

if [[ -z "${IN_CLUSTER}" ]]; then
    log info "Host check done!"
else
    log info "Cluster network check done!"
fi

if command -v kubectl >/dev/null 2>&1; then
    echo
    log info "Found cluster environment, performing cluster-scope network checks..."
    echo
    log info "Checking cluster network..."
    kubectl run -n "$NAMESPACE" \
        -it --rm \
        check-network \
        --overrides='{ "spec": { "imagePullSecrets": [{"name": "lkc-registry"}] } }' \
        --image="$REGISTRY_SERVER/leukocyte-lab/check-network:latest" \
        --env IN_CLUSTER=true \
        --env LICENSE_SERVER="$LICENSE_SERVER" \
        --env REGISTRY_SERVER="$REGISTRY_SERVER" \
        --env RELEASE_CHANNEL_SERVER="$RELEASE_CHANNEL_SERVER" \
        --env ARTIFACT_SERVER="$ARTIFACT_SERVER" \
        --env POINT_SYS_SERVER="$POINT_SYS_SERVER" \
        --env CHART_SERVER="$CHART_SERVER" \
        --restart=Never
fi

log info "All checks done!"
