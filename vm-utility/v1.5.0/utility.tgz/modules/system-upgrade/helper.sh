#!/usr/bin/env bash

confirmation() {
  echo
  log info "Confirmation"
  
  while true ; do
    log info "Upgrade $BRAND to the latest version"
    log warn "This will perform system upgrade, which may cause downtime and can not be undone."
    echo -ne "\t  $(color "Are you sure you want to continue?" "fg-yellow") "
    read -p "(y/N):" -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]] ; then
      log info "Performing system upgrade..."
      
      upgrade_loop;
      break;
    else
      log info "Operation cancelled, no changes made"
      
      break;
    fi
  done
}

upgrade_precheck() {
  get_latest_available_chart_version;
  current_chart_version=$(get_current_chart_version);

  if [ -z "$latest_chart_version" ] || [ -z "$current_chart_version" ]; then
    log error "Failed to get version information, upgrade aborted"
    return 1;
  elif [ "$latest_chart_version" == "$current_chart_version" ]; then
    log info "Current version is up-to-date"

    if [[ "$1" == "-f" || "$1" == "--force" ]]; then
      log warn "Force upgrade requested"
    else
      return 1;
    fi
  fi

  log info "Current version: $SYSTEM_VERSION (chart: $current_chart_version)"
  log info "Latest version: $latest_app_version (chart: $latest_chart_version)"
}

upgrade_loop() {
  if ! upgrade_do_k3s_upgrade; then
    log error "System upgrade failed"
    return 1;
  fi

  echo -ne "$(log info "Waiting for system performing Helm operation after k3s upgrade on $BRAND...")"
  sleep 30;
  if kubectl -n kube-system wait --for=condition=complete "jobs/helm-install-$CHART_NAME" --timeout 300s > /dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    color "[FAILED]" "bold fg-red"
    log error "K3s failed to apply $BRAND HelmChart after k3s upgrade"
    log error "System upgrade failed"
    return 1
  fi

  echo -ne "$(log info "Generating dependence manifest: Kueue...")";
  kueue_manifest=$(generate_kueue_manifest);
  color "[DONE]" "bold fg-green";

  echo -ne "$(log info "Applying dependence manifest: Kueue...")";
  if echo "$kueue_manifest" | kubectl apply -f - >/dev/null 2>&1; then
    color "[DONE]" "bold fg-green";
  else
    color "[FAILED]" "bold fg-red";
    log error "Failed to apply dependence manifest: Kueue"
    return 1;
  fi

  echo -ne "$(log info "Waiting for dependence provision to finish: Kueue...")";
  sleep 10;

  if kubectl -n kueue-system rollout status deploy --timeout 600s >/dev/null 2>&1; then
    color "[DONE]" "bold fg-green";
  else
    color "[FAILED]" "bold fg-red";
    log error "Failed to install dependence: kueue"
    return 1;
  fi

  if ! upgrade_do_db_migration; then
    log error "Database migration failed, system upgrade aborted"
    return 1;
  fi

  if ! get_crds_from_chart "$latest_chart_version"; then
    return 1;
  elif ! install_crds; then
    return 1;
  elif ! patch_helm_chart "$latest_chart_version"; then
    return 1;
  fi

  echo -ne "$(log info "Waiting for system performing Helm operation on $BRAND...")"
  sleep 10;
  if kubectl -n kube-system wait --for=condition=complete "jobs/helm-install-$CHART_NAME" --timeout 300s > /dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    color "[FAILED]" "bold fg-red"
    log error "Failed to apply $BRAND HelmChart modifications"
    log error "System upgrade failed"
    return 1
  fi

  echo -ne "$(log info "Waiting for $BRAND to be ready...")"
  if kubectl -n "$NAMESPACE" rollout status deploy/action-loop deploy/captain deploy/controller --timeout 600s >/dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
    log success "System upgrade completed successfully"
  else
    color "[FAILED]" "bold fg-red"
    log error "System upgrade failed"
    return 1
  fi
}

upgrade_do_k3s_upgrade() {
  K3S_TMP_BIN="$(mktemp /tmp/k3s.XXXXXX)";
  trap 'rm -f "$K3S_TMP_BIN"' EXIT ERR INT

  CURRENT_K3S_VERSION="$(kubectl get "node/$(hostname)" -o=jsonpath='{.status.nodeInfo.kubeletVersion}')";
  TARGET_K3S_VERSION="v1.28.15+k3s1";
  K3S_BIN_PATH="$(command -v k3s || echo "/usr/local/bin/k3s")";

  if [ -z "$CURRENT_K3S_VERSION" ]; then
    log error "Failed to get current k3s version"
    return 1;
  fi
  if [ -z "$K3S_BIN_PATH" ]; then
    log error "k3s binary not found, please install k3s first"
    return 1;
  fi
  
  if version_lt "$CURRENT_K3S_VERSION" "$TARGET_K3S_VERSION"; then
    log info "Current k3s version: $CURRENT_K3S_VERSION"
    log info "Upgrading k3s to $TARGET_K3S_VERSION..."
    
    echo -ne "$(log info "Downloading k3s $TARGET_K3S_VERSION...")"
    if curl -L "https://github.com/k3s-io/k3s/releases/download/$TARGET_K3S_VERSION/k3s" -o "$K3S_TMP_BIN" >/dev/null 2>&1; then
      color "[DONE]" "bold fg-green";
      log success "Downloaded k3s $TARGET_K3S_VERSION successfully"
    else
      color "[FAILED]" "bold fg-red";
      log error "Failed to download k3s $TARGET_K3S_VERSION"
      return 1;
    fi

    echo -ne "$(log info "Stopping k3s service...")"
    if sudo systemctl stop k3s.service >/dev/null 2>&1; then
      color "[DONE]" "bold fg-green";
    else
      color "[FAILED]" "bold fg-red";
      log error "Failed to stop k3s service"
      return 1;
    fi

    echo -ne "$(log info "Installing k3s $TARGET_K3S_VERSION...")"
    if sudo install -m 755 "$K3S_TMP_BIN" "$K3S_BIN_PATH" >/dev/null 2>&1; then
      color "[DONE]" "bold fg-green";
      log success "Installed k3s $TARGET_K3S_VERSION successfully"
    else
      color "[FAILED]" "bold fg-red";
      log error "Failed to install k3s $TARGET_K3S_VERSION"
      return 1;
    fi

    echo -ne "$(log info "Starting k3s service...")"
    if sudo systemctl start k3s.service >/dev/null 2>&1; then
      color "[DONE]" "bold fg-green";
    else
      color "[FAILED]" "bold fg-red";
      log error "Failed to start k3s service"
      return 1;
    fi

    echo -ne "$(log info "Waiting for k3s to be ready...")"
    sleep 30;
    if kubectl wait --for=condition=Ready "node/$(hostname)" --timeout 300s >/dev/null 2>&1; then
      color "[DONE]" "bold fg-green";
    else
      color "[FAILED]" "bold fg-red";
      log error "Failed to wait for k3s to be ready"
      return 1;
    fi
    NOW_K3S_VERSION="$(kubectl get "node/$(hostname)" -o=jsonpath='{.status.nodeInfo.kubeletVersion}')";
    
    log success "k3s upgraded to $NOW_K3S_VERSION successfully"
  else
    log info "k3s is already up-to-date: $CURRENT_K3S_VERSION"
    return 0;
  fi
}

get_current_chart_version() {
  kubectl -n kube-system get "HelmChart/$CHART_NAME" -o=jsonpath='{.spec.version}';
}

get_latest_available_chart_version() {
  echo -ne "$(log info "Checking latest available version...")";

  if curl -sS "https://$CHART_SERVER/index.yaml" > /tmp/chart_index.yaml; then
    # shellcheck disable=SC2002
    version="$(cat /tmp/chart_index.yaml |\
      sed -n "/^\s\s$CHART_NAME:$/,/^\s\s$CHART_NAME:$/ { /^\s\s$CHART_NAME:/!p; }" |\
      sed -n '/^\s\s\s\sappVersion: v3.10./,/^\s\s\s\sversion:/ { p; /^\s\s\s\sversion:/q }' |\
      sed -n 's/^\s\s\s\sversion: //p')";
    # shellcheck disable=SC2002
    appVersion="$(cat /tmp/chart_index.yaml |\
      sed -n "/^\s\s$CHART_NAME:$/,/^\s\s$CHART_NAME:$/ { /^\s\s$CHART_NAME:/!p; }" |\
      sed -n '/^\s\s\s\sappVersion: v3.10./,/^\s\s\s\sversion:/ { p; /^\s\s\s\sversion:/q }' |\
      sed -n 's/^\s\s\s\sappVersion: //p')";

    rm -f /tmp/chart_index.yaml;

    if [ -z "$version" ]; then
      color "[FAILED]" "bold fg-red";
      log error "Failed to get latest available version"
      return 1;
    fi

    color "[DONE]" "bold fg-green";
    log info "Found latest available version: $appVersion (chart: $version)"

    latest_chart_version="$version";
    latest_app_version="$appVersion";
  else
    color "[FAILED]" "bold fg-red";
    log error "Failed to get latest available version"
    return 1;
  fi
}

generate_kueue_manifest() {
  sed "s/%CHART_SERVER%/$REGISTRY_SERVER/g" < "$DIR_PATH/modules/system-upgrade/kueue.helmchart.yaml"
}

upgrade_do_db_migration() {
  echo -ne "$(log info "Performing database migration...")"
  delete_incompatible_integrations_query="$(cat << EOF
MERGE INTO integrations AS integration_table
USING (VALUES
    ('8202bc49-5789-4233-802e-0a25d9745994')
) AS vals (device_id)
ON integration_table.device_id = 'f5-big-ip-asm@13-18'
WHEN matched THEN
  UPDATE SET device_id = vals.device_id;
EOF
    )";
  
  if _db captain-db "$delete_incompatible_integrations_query"; then
    color "[DONE]" "bold fg-green";
    log success "Database migration completed successfully"
  else
    color "[FAILED]" "bold fg-red";
    log error "Database migration failed"
    return 1;
  fi
}

patch_helm_chart() {
  target_chart_version=$1;
  
  if [ -z "$target_chart_version" ]; then
    log error "Invalid target chart version"
    return 1;
  fi

  echo -ne "$(log info "Applying $BRAND upgrade: $target_chart_version...")"
  if kubectl -n kube-system patch "HelmChart/$CHART_NAME" --type='json' -p='[{"op": "replace", "path": "/spec/version", "value": "'"$target_chart_version"'"}, {"op": "replace", "path": "/spec/set/kueue.enabled", "value": "true"}]' >/dev/null 2>&1; then
    color "[DONE]" "bold fg-green";
  else
    color "[FAILED]" "bold fg-red";
    log error "Failed to upgrade $BRAND"
    return 1;
  fi
}

get_crds_from_chart() {
  target_chart_version=$1;

  if [ -z "$target_chart_version" ]; then
    log error "Invalid target chart version"
    return 1;
  fi

  rm -rf "/tmp/$CHART_NAME";
  
  echo -ne "$(log info "Downloading CRDs from chart: $target_chart_version...")"
  if curl -sS "https://$CHART_SERVER/$CHART_NAME-$target_chart_version.tgz" > /tmp/chart.tgz; then
    color "[DONE]" "bold fg-green";
  else
    color "[FAILED]" "bold fg-red";
    log error "Failed to download CRDs from chart."
    return 1;
  fi

  echo -ne "$(log info "Extracting CRDs from chart: $target_chart_version...")"
  if tar -xzf /tmp/chart.tgz -C "/tmp" --wildcards "$CHART_NAME/crds/*"; then
    color "[DONE]" "bold fg-green";
  else
    color "[FAILED]" "bold fg-red";
    log error "Failed to extract CRDs from chart."
    return 1;
  fi
}

install_crds() {
  echo -ne "$(log info "Installing CRDs...")"
  if kubectl apply -f "/tmp/$CHART_NAME/crds" > /dev/null 2>&1; then
    color "[DONE]" "bold fg-green";
  else
    color "[FAILED]" "bold fg-red";
    log error "Failed to install CRDs."
    return 1;
  fi
}
