#!/usr/bin/env bash

# shellcheck disable=SC2034
description_ip="Configure IP address for the VM"

alias system_ip='$(which ip)'

ip() {
  source "$DIR_PATH/modules/ip/helper.sh"
  source "$DIR_PATH/modules/ip/update-ip-netplan.sh"
  source "$DIR_PATH/modules/ip/update-ip-k3s.sh"

  if [[ -z $1 ]]; then
    cmd;
  else
    system_ip "$@";
  fi
}

cmd() {
  echo
  check_if_root;
  if [ $? -eq 1 ]; then
    echo
    return 1
  fi

  ip_promote;

  if update_netplan_ip; then
    log success "Netplan configuration applied successfully"
  else
    log error "Netplan configuration failed"
    return 1
  fi

  if [[ "$VM_TYPE" != "CTR3_PLAYER" ]]; then
    return 0
  fi

  if command -v kubectl >/dev/null 2>&1; then
    if update_k3s_ip; then
      log success "k3s configuration applied successfully"
    else
      log error "k3s configuration failed"
      return 1
    fi
  fi

  echo
  echo -ne "$(log info "Waiting for k3s to be ready...")"
  if kubectl wait --for=condition=ready --timeout=60s node/"$(hostname)" >/dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    log error "Node is not ready";
    log error "IP configuration failed";
    return 1
  fi

  echo -ne "$(log info "Trigger CoreDNS restart...")"
  kubectl -n kube-system rollout restart deploy/coredns >/dev/null 2>&1;
  color "[DONE]" "bold fg-green"

  log info "Performing health check..."
  echo
  echo -ne "$(log info "Waiting for CoreDNS to be ready...")"
  sleep 10
  if kubectl -n kube-system wait --for=condition=ready pods -l k8s-app=kube-dns --timeout 120s >/dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    log warn "CoreDNS is not ready";
    log warn "IP configuration successfully, but health check not passed";
    return 1
  fi

  if kubectl wait --for=condition=ready --timeout=60s node/"$(hostname)" >/dev/null 2>&1; then
    log success "IP configuration successfully";
  else
    log error "IP configuration failed due to node not ready";
    return 1
  fi

  echo
}
