#!/usr/bin/env bash

# shellcheck disable=SC2034
description_restore="Restore $BRAND data from backup"

restore_pv() {
  pvc_name=$1;
  pv_path=$(get_pv_path "$pvc_name");
  filename="/tmp/backup-$pvc_name.tgz";
  lockfile="$pv_path/.user_scripts_initialized";

  log info "Restoring $pvc_name data to $pv_path";
  sudo tar -xzf "$filename" -C "$pv_path" .;
  
  if [ -e "$lockfile" ]; then
    sudo rm -f "$lockfile";
  fi
}

get_pv_path() {
  pvc_name=$1;
  
  if [[ $(kubectl get nodes) == *"etcd"* ]]; then
    mode="hostPath";
  else
    mode="local";
  fi

  kubectl get "$(kubectl -n "$NAMESPACE" get "pvc/$pvc_name" -o=jsonpath='pv/{.spec.volumeName}')" -o=jsonpath="{.spec.$mode.path}";
}

restore_procedure() {
  restore_pv "data-db-0";
  exit_code=$?

  if [ $exit_code -ne 0 ]; then
    log error "Restore failed"
    return 1
  fi

  restore_pv "minio";
  exit_code=$?

  if [ $exit_code -eq 0 ]; then
    log success "Restore completed successfully"
  else
    log error "Restore failed"
    return 1
  fi

  rm -rf /tmp/backup-data-db-0.tgz /tmp/backup-minio.tgz;

  echo -ne "$(log info "Restarting services...")";
  kubectl -n "$NAMESPACE" rollout restart sts/db sts/redis-master deploy/minio deploy/captain deploy/controller >/dev/null 2>&1;
  kubectl -n "$NAMESPACE" rollout status sts/db sts/redis-master deploy/minio deploy/captain deploy/controller --timeout 600s >/dev/null 2>&1;

  if [ $? -eq 1 ]; then
    color "[FAILED]" "bold fg-red";
    log error "Services failed to restart"
    return 1;
  else
    color "[DONE]" "bold fg-green";
    log success "Restore procedure completed successfully, $BRAND is ready for use"
  fi
}

sync_secret() {
  curr_token="$(kubectl -n kube-system get "HelmChart/$CHART_NAME" -o=jsonpath='{.spec.set.keygen\.apiToken}')";
  new_token="$(cat /tmp/token)";
  rm -f /tmp/token;

  if [ "$curr_token" != "$new_token" ]; then
    echo -ne "$(log info "Syncing token...")";
    kubectl -n kube-system patch "HelmChart/$CHART_NAME" --type='json' -p='[{"op": "replace", "path": "/spec/set/keygen.apiToken", "value": "'"$new_token"'"}]' >/dev/null 2>&1;
    if [ $? -eq 0 ]; then
      color "[DONE]" "bold fg-green";
    else
      color "[FAILED]" "bold fg-red";
      return 1;
    fi

    log info "Waiting for $BRAND provision...";
    sleep 30;
    log info "Performing secrets migration...";
    kubectl -n "$NAMESPACE" delete pvc/data-rabbitmq-0 --force --grace-period=0 --wait=false >/dev/null 2>&1;
    kubectl -n "$NAMESPACE" delete pods/rabbitmq-0 --force >/dev/null 2>&1;
    kubectl rollout restart deploy/controller >/dev/null 2>&1;
  fi
}

backup_file_extract() {
  filename="$1"

  sudo rm -rf /tmp/backup-data-db-0.tgz /tmp/backup-minio.tgz;

  log info "Extracting backup file $filename"
  tar -xf "$filename" -C "/tmp";

  if [ -e "/tmp/backup-data-db-0.tgz" ] && [ -e "/tmp/backup-minio.tgz" ] && [ -e "/tmp/token" ]; then
    sync_secret;
    restore_procedure;
  else
    log error "Failed to extract from backup file, or backup file is corrupted"
    return 1
  fi
}

restore() {
  echo
  check_if_root
  if [ $? -eq 1 ]; then
    echo
    return 1
  fi

  if [[ "$1" == "-h" || "$1" == "--help" || -z "$1" ]]; then
    restore_help
  elif [[ -e "$1" ]]; then
    log info "Performing restore procedure"
    log warn "Please DO NOT use $BRAND while the restore procedure is in progress"
    backup_file_extract "$1"
  else
    log error "Invalid backup file path, or specified file does not exist"
    restore_help
  fi
}

restore_help() {
  echo
  echo -e "Usage: $(color "restore" "bold fg-yellow") $(color "(options)" "bold fg-green")"
  echo
  echo -e "$(color "Options" "bold fg-white")"
  echo -e "  $(color "restore" "bold fg-yellow") $(color "[file]" "bold fg-green") \t Restore $BRAND data from backup file"
  echo
}
