#!/usr/bin/env bash
# shellcheck disable=SC2034

load_bashrc() {
  if [ -f "$HOME/.bashrc" ]; then
    # shellcheck disable=SC1091
    source "$HOME/.bashrc"
  fi
}

load_vm_info() {
  if [ -f "$HOME/.vmrc" ]; then
    # shellcheck disable=SC1091
    source "$HOME/.vmrc"
  elif [ -f "$DIR_PATH/.vmrc" ]; then
    # shellcheck disable=SC1091
    source "$DIR_PATH/.vmrc"
  fi

  if [[ -n "$VM_TYPE" ]]; then
    declare -A VM_NAME_MAP
    VM_NAME_MAP["CTR3_PLAYER"]="${BRAND}3 CTR Player"
    VM_NAME_MAP["C2_AGENT_SERVER"]="${BRAND} C2 Agent Server"
    VM_NAME_MAP["SYSTEM_AGENT_SERVER"]="${BRAND} System Agent Server"

    declare -A VM_SUPPORT_MODULE_MAP
    VM_SUPPORT_MODULE_MAP["CTR3_PLAYER"]="ip proxy bind-ip benchmark check-network version help"
    VM_SUPPORT_MODULE_MAP["C2_AGENT_SERVER"]="ip benchmark help"
    VM_SUPPORT_MODULE_MAP["SYSTEM_AGENT_SERVER"]="ip benchmark help"

    VM_NAME="${VM_NAME_MAP[$VM_TYPE]}"
    VM_SUPPORT_MODULES="${VM_SUPPORT_MODULE_MAP[$VM_TYPE]}"
  else
    UNSUPPORTED=true
  fi
}

load_module() {
  # shellcheck disable=SC2206
  MODULES=($VM_SUPPORT_MODULES)
  INSTALLED_MODULES=()
  if [[ -n "$VM_SUPPORT_MODULES" ]] ; then
    for module in "${MODULES[@]}"; do
      if [ -f "$DIR_PATH/modules/$module/main.sh" ]; then
        # shellcheck disable=SC1090
        source "$DIR_PATH/modules/$module/main.sh"
        INSTALLED_MODULES+=("$module")
      fi
    done
  fi
}
