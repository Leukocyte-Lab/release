#!/bin/bash --init-file

# shellcheck disable=SC2034
UTILITY_VERSION="v1.3.0"
SCRIPT_PATH=$(readlink -f "${BASH_SOURCE:-$0}")
DIR_PATH=$(dirname "${SCRIPT_PATH}")
PATH=$DIR_PATH/bin/:$PATH

source "$DIR_PATH/helpers/color.sh"
source "$DIR_PATH/helpers/logging.sh"

log_prefix 0
log_level info

source "$DIR_PATH/helpers/permission.sh"
source "$DIR_PATH/helpers/loader.sh"

load_bashrc
load_vm_info

if [[ -n "$UNSUPPORTED" ]]; then
  log error "Unsupported platform or script failed to init."
  log error "Check if the script is compatible with your platform, or config file (.vmrc) is correct."
  return 1
fi

load_module

echo
greeting
help

update --startup-check

PS1='\[\033[01;34m\]\w\[\033[00m\]\$ '
