#!/usr/bin/env bash

# shellcheck disable=SC2034
description_version="Show version information"

if command -v kubectl >/dev/null 2>&1; then
  SYSTEM_VERSION="$(kubectl -n "$NAMESPACE" get deploy/captain -o=jsonpath='{.spec.template.spec.containers[?(@.name=="captain")].env[?(@.name=="APP_VERSION")].value}')"
fi



version() {
  echo
  echo -e "$(color "$VM_NAME" "bold fg-white")"
  echo
  if [[ -n "$SYSTEM_VERSION" ]]; then
    echo -e "System Version: \t $(color "$SYSTEM_VERSION" "bold fg-white")"
  fi
  if [[ "$VM_TYPE" == "SYSTEM_AGENT_SERVER" ]]; then
    echo -e "Agent Server Version: \t $(color "v$(dpkg -s bas-system-agent | grep -i version  | awk '{ print $2 }')" "bold fg-white")"
  fi
  if [[ "$VM_TYPE" == "C2_AGENT_SERVER" ]]; then
    echo -e "Agent Server Version: \t $(color "v$(dpkg -s bas-c2-agent | grep -i version  | awk '{ print $2 }')" "bold fg-white")"
  fi
  echo -e "Utility Version: \t $(color "$UTILITY_VERSION" "bold fg-white")"
  echo
}
