#!/usr/bin/env bash

# shellcheck disable=SC2034
description_benchmark="Run Disk IO benchmark tests"

benchmark() {
  #? DIR_PATH is set in the main script
	# shellcheck disable=SC1091,SC2153
  source "$DIR_PATH/modules/benchmark/helper.sh"

  echo
  log info "Performing Disk I/O benchmark..."
  disk_test
  echo

  if [[ $DISK_IOPS_RAW -lt 4800 ]]; then
    log error "Disk IOPS is less than 4800, which may cause system unstable. Consider upgrading your disk for better performance."
  elif [[ $DISK_IOPS_RAW -lt 7500 ]]; then
    log warning "Disk IOPS is less than 7500, which may affect system performance. Consider upgrading your disk for better performance."
  else
    log success "Your disk is performing well."
  fi

  echo
}
