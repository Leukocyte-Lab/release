#!/usr/bin/env bash

# shellcheck disable=SC2034
description_user_mgr="User Management"

alias user-mgr="user_mgr"

user_mgr() {
  # shellcheck disable=SC1091
  source "$DIR_PATH/modules/user-mgr/helper.sh"

  if [[ "$1" == "passwd" ]]; then
    _user_mgr_passwd;
  elif [[ "$1" == "reset-admin-passwd" ]]; then
    _user_mgr_reset_admin_passwd;
  elif [[ "$1" == "-h" || "$1" == "--help" || -z "$1" ]]; then
    _user_mgr_help
  else
    log error "Invalid option: $1"
    _user_mgr_help
  fi
}

_user_mgr_help() {
  echo
  echo -e "Usage: $(color "user-mgr" "bold fg-yellow") $(color "(options)" "bold fg-green")"
  echo
  echo -e "$(color "Options" "bold fg-white")"
  echo -e "  $(color "user-mgr" "bold fg-yellow") $(color "passwd" "bold fg-green") \t Change the password of the user on the $BRAND system"
  echo -e "  $(color "user-mgr" "bold fg-yellow") $(color "reset-admin-passwd" "bold fg-green") \t Reset the password of the admin user on the $BRAND system"
  echo
}
