#!/usr/bin/env bash

_user_mgr_passwd() {
  log info "User asked for changing the password of the user on the $BRAND system"

  _user_mgr_username_prompt;
}

_user_mgr_reset_admin_passwd() {
  log info "User asked for reset the password of the admin user on the $BRAND system"

  _user_mgr_admin_passwd_prompt;
}

_user_mgr_get_user_by_name() {
  local username="$1"
  local query

  query="$(cat << EOF
SELECT *
  FROM users
  WHERE username = '$username';
EOF
  )";

  _db captain-db "$query";
}

_user_mgr_admin_passwd_prompt() {
  read -rp "$(echo -ne "\t$(color "Enter admin's username: " "fg-cyan")")" USERNAME
  if [[ -z "$USERNAME" ]]; then
    log error "Username cannot be empty"

    _user_mgr_admin_passwd_prompt;
  elif _user_mgr_passwd_prompt; then
    _user_mgr_passwd_upsert "$USERNAME" "$NEW_PASSWD" "ADMIN";
  fi

  unset USERNAME;
  unset NEW_PASSWD;
  unset NEW_PASSWD_CONFIRM;
}

_user_mgr_username_prompt() {
  read -rp "$(echo -ne "\t$(color "Enter username: " "fg-cyan")")" USERNAME
  if [[ -z "$USERNAME" ]]; then
    log error "Username cannot be empty"

    _user_mgr_username_prompt;
  elif ! _user_mgr_get_user_by_name "$USERNAME" | grep '' > /dev/null; then
    log error "User $USERNAME does not exist"

    _user_mgr_username_prompt;
  elif _user_mgr_passwd_prompt; then
    _user_mgr_passwd_upsert "$USERNAME" "$NEW_PASSWD";
  fi

  unset USERNAME;
  unset NEW_PASSWD;
  unset NEW_PASSWD_CONFIRM;
}

_user_mgr_passwd_prompt() {
  read -rsp "$(echo -e "\t$(color "Enter new password: " "fg-cyan")")" NEW_PASSWD

  if [[ -z "$NEW_PASSWD" ]]; then
    log error "Password cannot be empty"

    _user_mgr_passwd_prompt;
  fi

  echo
  read -rsp "$(echo -e "\t$(color "Re-enter new password: " "fg-cyan")")" NEW_PASSWD_CONFIRM
  echo

  if [[ "$NEW_PASSWD" != "$NEW_PASSWD_CONFIRM" ]]; then
    log error "Passwords do not match"

    _user_mgr_passwd_prompt;
  fi
}

_user_mgr_passwd_upsert() {
  local username="$1"
  local new_passwd="$2"
  local role="$3"
  local encrypted_passwd
  local query

  echo -ne "$(log info "Generating hash for password...")"

  # Encrypt the password using bcrypt
  encrypted_passwd=$(_bcrypt_cmd "$new_passwd")

  if [[ -z "$encrypted_passwd" ]]; then
    color "[FAILED]" "bold fg-red"
    log error "Failed to generate hash for password"
    return 1
  else
    color "[DONE]" "bold fg-green"
  fi

  log info "Updating password for user $username"

  if [[ -z "$role" ]]; then
    query="$(cat << EOF
MERGE INTO users AS user_table
USING (VALUES
    ('$username', '$encrypted_passwd')
) AS vals (username, password_hash)
ON user_table.username = vals.username
WHEN matched THEN
  UPDATE SET password_hash = vals.password_hash
WHEN NOT matched THEN
  INSERT (id, username, password_hash)
  VALUES (gen_random_uuid(), vals.username, vals.password_hash);
EOF
    )";
  else
    query="$(cat << EOF
MERGE INTO users AS user_table
USING (VALUES
    ('$username', '$encrypted_passwd', '$role')
) AS vals (username, password_hash, role)
ON user_table.username = vals.username
WHEN matched THEN
  UPDATE SET password_hash = vals.password_hash, role = vals.role
WHEN NOT matched THEN
  INSERT (id, username, password_hash, role)
  VALUES (gen_random_uuid(), vals.username, vals.password_hash, vals.role);
EOF
    )";
  fi

  if _db captain-db "$query"; then
    log success "Password for user $username updated successfully"
    log info "You can now login to the $BRAND system with the new password"
  else
    log error "Failed to update password for user $username"
    return 1
  fi
}

_bcrypt_cmd() {
  python3 - "$1" <<EOF
import bcrypt
import sys
if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python3 bcrypt.py <password>")
        sys.exit(1)
    password = sys.argv[1].encode('utf-8')
    sys.stdout.write(bcrypt.hashpw(password=password,salt=bcrypt.gensalt()).decode('utf-8'))
EOF
}
