#!/usr/bin/env bash

# shellcheck disable=SC2034
description_help="Show this help menu"

greeting() {
  TITLE=" $VM_NAME "
  LINE=""

  for ((i=0; i<${#TITLE}; i++)); do
    LINE="${LINE}="
  done

  color "$LINE"   "bold fg-purple"
  color "$TITLE"  "bold fg-purple"
  color "$LINE"   "bold fg-purple"
}

help() {
  echo
  echo -e "Usage: $(color "(command)" "bold fg-yellow") $(color "(options)" "bold fg-green")"
  echo
  echo -e "$(color "Options" "bold fg-white")"
  echo -e "  $(color "(command)" "bold fg-yellow") $(color "-h, --help" "bold fg-green") \t Show help message for the command"
  echo
  echo -e "$(color "Commands" "bold fg-white")"
  for module in "${INSTALLED_MODULES[@]}"; do
    DESC_VAR="description_${module//-/_}"
    DESC=${!DESC_VAR}
    echo -e "  $(color "$module" "bold fg-yellow")  \t  $DESC"  
  done
  echo
}
