#!/usr/bin/env bash

# shellcheck disable=SC1091
source "./helpers/color.sh"
source "./helpers/logging.sh"
source "./start.sh"
