#!/usr/bin/env bash

# shellcheck disable=SC2034
description_check_network="Check network connection to required services"

alias check-network="check_network"

check_network() {
  # shellcheck disable=SC1091
  source "$DIR_PATH/modules/check-network/start.sh"
}
