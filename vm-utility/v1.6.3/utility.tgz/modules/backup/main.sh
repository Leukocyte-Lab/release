#!/usr/bin/env bash

# shellcheck disable=SC2034
description_backup="Backup $BRAND data"

backup_pv() {
  pvc_name=$1;
  pv_path=$(get_pv_path "$pvc_name");
  filename="/tmp/backup-$pvc_name.tgz";

  rm -rf "$filename";
  log info "Backing up $pvc_name from $pv_path";

  sudo tar -czf "$filename" -C "$pv_path" . && \
    sudo chown "$USER:$USER" "$filename";

  # shellcheck disable=SC2181
  if [ $? -ne 0 ]; then
    log error "Backup failed"
    return 1
  fi
}

get_pv_path() {
  pvc_name=$1;
  
  if [[ $(kubectl get nodes) == *"etcd"* ]]; then
    mode="hostPath";
  else
    mode="local";
  fi

  kubectl get "$(kubectl -n "$NAMESPACE" get "pvc/$pvc_name" -o=jsonpath='pv/{.spec.volumeName}')" -o=jsonpath="{.spec.$mode.path}";
}

dump_token() {
  echo -ne "$(log info "Dumping token...")";

  if kubectl -n kube-system get "HelmChart/$CHART_NAME" -o=jsonpath='{.spec.set.keygen\.apiToken}' > /tmp/token; then
    color "[DONE]" "bold fg-green";
  else
    color "[FAILED]" "bold fg-red";
    return 1;
  fi
}

backup() {
  echo
  check_if_root
  if [ $? -eq 1 ]; then
    echo
    return 1
  fi

  backup_pv "data-db-0";
  exit_code=$?

  if [ $exit_code -ne 0 ]; then
    log error "Backup failed"
    return 1
  fi

  backup_pv "minio";
  exit_code=$?

  if [ $exit_code -ne 0 ]; then
    log error "Backup failed"
    return 1
  fi

  dump_token;
  if [ $exit_code -ne 0 ]; then
    log error "Backup failed"
    return 1
  fi

  filename="$HOME/backup-$(date '+%Y%m%d%H%M%S').tgz";
  log info "Creating backup file $filename";
  if tar -cf "$filename" -C /tmp "backup-data-db-0.tgz" "backup-minio.tgz" "token"; then
      rm -rf /tmp/backup-data-db-0.tgz /tmp/backup-minio.tgz /tmp/token;
  else
      log error "Creating backup file $filename failed. Temporary backup files retained."
      return 1
  fi

  # shellcheck disable=SC2181
  if [ $? -eq 0 ]; then
    log success "Backup completed successfully"
  fi
}