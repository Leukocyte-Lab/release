#!/usr/bin/env bash

update_k3s_ip() {
    export ETCDCTL_ENDPOINTS='https://127.0.0.1:2379'
    export ETCDCTL_CACERT='/var/lib/rancher/k3s/server/tls/etcd/server-ca.crt'
    export ETCDCTL_CERT='/var/lib/rancher/k3s/server/tls/etcd/server-client.crt'
    export ETCDCTL_KEY='/var/lib/rancher/k3s/server/tls/etcd/server-client.key'
    export ETCDCTL_API=3

    if sudo -E "$DIR_PATH/bin/etcdctl" endpoint status >/dev/null 2>&1; then
        IS_ETCD_INSTANCE=true
    fi

    if [[ -n "$IS_ETCD_INSTANCE" ]]; then
        echo
        log info "Applying IP on k3s..."
        log info "Backup configuration: "
        
        sudo cp /etc/systemd/system/k3s.service "$DIR_PATH/k3s.service.bak"
        log info "  /etc/systemd/system/k3s.service -> $DIR_PATH/k3s.service.bak"

        cat <<EOF | sudo tee /etc/systemd/system/k3s.service >/dev/null
[Unit]
Description=Lightweight Kubernetes
Documentation=https://k3s.io
Wants=network-online.target
After=network-online.target

[Install]
WantedBy=multi-user.target

[Service]
Type=notify
EnvironmentFile=-/etc/default/%N
EnvironmentFile=-/etc/sysconfig/%N
EnvironmentFile=-/etc/systemd/system/k3s.service.env
KillMode=process
Delegate=yes
# Having non-zero Limit*s causes performance problems due to accounting overhead
# in the kernel. We recommend using cgroups to do container-local accounting.
LimitNOFILE=1048576
LimitNPROC=infinity
LimitCORE=infinity
TasksMax=infinity
TimeoutStartSec=0
Restart=always
RestartSec=5s
ExecStartPre=/bin/sh -xc '! /usr/bin/systemctl is-enabled --quiet nm-cloud-setup.service'
ExecStartPre=-/sbin/modprobe br_netfilter
ExecStartPre=-/sbin/modprobe overlay
ExecStart=/usr/local/bin/k3s \\
    server \\
    '--flannel-iface=$IFACE' \\
    '--advertise-address' \\
    '$IP' \\
    '--tls-san' \\
    '$IP' \\
    '--disable=local-storage' \\
    '--node-label=purpose=worker' \\
    '--cluster-init'
EOF

        MEMBER_ID=$(sudo -E "$DIR_PATH/bin/etcdctl" member list | awk -F "," '{print $1}')
        sudo -E "$DIR_PATH/bin/etcdctl" member update "$MEMBER_ID" --peer-urls="https://$IP:2380"

        sudo systemctl daemon-reload
    fi

    sudo systemctl restart k3s.service
}
