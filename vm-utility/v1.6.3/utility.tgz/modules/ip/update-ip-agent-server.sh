#!/usr/bin/env bash

update_agent_server_ip() {
    local AGENT_SERVER_NAME
    local AGENT_SERVICE_NAME

    AGENT_SERVER_NAME=$(_get_agent_server_name)
    AGENT_SERVICE_NAME="bas-$(_get_agent_server_name)"

    local SERVER_CONFIG_FILE="/app/${AGENT_SERVER_NAME}/resources/server.yaml"
    local CHANNEL_CONFIG_FILE="/app/${AGENT_SERVER_NAME}/resources/channels.yaml"

    log info "Backup configuration: "
    sudo cp "$SERVER_CONFIG_FILE" "$DIR_PATH/${AGENT_SERVER_NAME}_server.yaml.bak"
    log info "  $SERVER_CONFIG_FILE -> $DIR_PATH/${AGENT_SERVER_NAME}_server.yaml.bak"
    sudo cp "$CHANNEL_CONFIG_FILE" "$DIR_PATH/${AGENT_SERVER_NAME}_channels.yaml.bak"
    log info "  $CHANNEL_CONFIG_FILE -> $DIR_PATH/${AGENT_SERVER_NAME}_channels.yaml.bak"

    echo -ne "$(log info "Applying IP Changes on $AGENT_SERVICE_NAME...")"
    sudo "$DIR_PATH/bin/yq" -i ".agent_callback_base_host = \"$IP\"" "$SERVER_CONFIG_FILE" && \
    sudo "$DIR_PATH/bin/yq" -i "(.instruction_channel[] | select(.name == \"http\").url) |= \"http://$IP/api/agents/heartbeat\"" "$CHANNEL_CONFIG_FILE" && \
    sudo "$DIR_PATH/bin/yq" -i "(.instruction_channel[] | select(.name == \"https\").url) |= \"https://$IP/api/agents/heartbeat\"" "$CHANNEL_CONFIG_FILE" && \
    sudo "$DIR_PATH/bin/yq" -i "(.response_channel[] | select(.name == \"http\").url) |= \"http://$IP/api/agents/response\"" "$CHANNEL_CONFIG_FILE" && \
    sudo "$DIR_PATH/bin/yq" -i "(.response_channel[] | select(.name == \"https\").url) |= \"https://$IP/api/agents/response\"" "$CHANNEL_CONFIG_FILE"

    # shellcheck disable=SC2181
    if [ $? -ne 0 ]; then
        log error "Failed to apply IP configuration for $AGENT_SERVICE_NAME"
        return 1
    else
        color "[DONE]" "bold fg-green"
    fi

    echo -ne "$(log info "Restarting $AGENT_SERVICE_NAME...")"
    if ! sudo systemctl restart "$AGENT_SERVICE_NAME".service; then
        color "[FAILED]" "bold fg-red"
        log error "Failed to restart $AGENT_SERVICE_NAME"
        return 1
    else
        color "[DONE]" "bold fg-green"
    fi

    echo -ne "$(log info "Verifying $AGENT_SERVICE_NAME status...")"
    if ! sudo systemctl is-active --quiet "$AGENT_SERVICE_NAME".service; then
        color "[FAILED]" "bold fg-red"
        log error "$AGENT_SERVICE_NAME is not running"
        return 1
    else
        color "[DONE]" "bold fg-green"
    fi

    log success "$AGENT_SERVICE_NAME IP configuration applied successfully"
}

_get_agent_server_name() {
    if [[ "$VM_TYPE" == "SYSTEM_AGENT_SERVER" ]]; then
        echo "system-agent"
    elif [[ "$VM_TYPE" == "C2_AGENT_SERVER" ]]; then
        echo "c2-agent"
    fi
}