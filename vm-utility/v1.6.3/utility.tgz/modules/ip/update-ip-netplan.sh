#!/usr/bin/env bash

update_netplan_ip() {
  echo
  log info "Applying IP on netplan..."
  mkdir -p "$DIR_PATH/netplan-backups/"
  log info "Backup configurations: "
  log info "  /etc/netplan/*.yaml -> $DIR_PATH/netplan-backups/"

  sudo cp /etc/netplan/*.yaml "$DIR_PATH/netplan-backups/"

  sudo rm /etc/netplan/*.yaml

  cat <<EOF | sudo tee /etc/netplan/00-installer-config.yaml
# This is the network config written by '$VM_NAME IP Utility'
network:
  ethernets:
    $IFACE:
      addresses:
        - $IP_CIDR
      routes:
        - to: default
          via: $GATEWAY
      nameservers:
        addresses:
          - $DNS
  version: 2
EOF

  sudo chmod 500 /etc/netplan/00-installer-config.yaml
  sudo netplan apply
}