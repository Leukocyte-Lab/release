#!/usr/bin/env bash

ip_promote() {
  log info "User asked to modify IP configuration"
  
  IFACE_DEFAULT=$(system_ip r | awk '$1 == "default" { print $5 }' | head -n 1);

  read -rp "$(echo -ne "\t$(color "Enter IP:\n  \t(IPv4, MUST be formatted in CIDR, ex: 10.13.2.12/16): " "fg-cyan")")" IP_CIDR
  read -rp "$(echo -ne "\t$(color "Enter Gateway IP (IPv4): " "fg-cyan")")" GATEWAY
  read -rp "$(echo -ne "\t$(color "Enter DNS Server (IPv4): " "fg-cyan")")" DNS

  if [ -z "$IFACE_DEFAULT" ]; then
    read -rp "$(echo -ne "\t$(color "Interface to Update: " "fg-cyan")")" IFACE_SPECIFIED
  else
    read -rp "$(echo -ne "\t$(color "Interface to Update (default \"$IFACE_DEFAULT\"): " "fg-cyan")")" IFACE_SPECIFIED
  fi

  IP="$(echo "$IP_CIDR" | cut -d"/" -f1)";
  IFACE="${IFACE_SPECIFIED:-$IFACE_DEFAULT}";

  export IP_CIDR;
  export IP;
  export GATEWAY;
  export DNS;
  export IFACE;

  validation;
}

validation() {
  echo "$SUBNET";
  if [ -z "$IP_CIDR" ]; then
    log error "Missing required fields: IP"
    ip_promote;
  elif [ -z "$GATEWAY" ]; then
    log error "Missing required fields: Gateway"
    ip_promote;
  elif [ -z "$DNS" ]; then
    log error "Missing required fields: DNS"
    ip_promote;
  elif [ -z "$IFACE" ]; then
    log error "Missing required fields: Interface"
    ip_promote;
  elif ! _validator_is_valid_cidr "$IP_CIDR"; then
    log error "Invalid IP format, MUST be a CIDR"
    ip_promote;
  elif ! _validator_is_valid_ipv4 "$GATEWAY"; then
    log error "Invalid Gateway format, MUST be IPv4"
    ip_promote;
  elif ! _validator_is_valid_ipv4 "$DNS"; then
    log error "Invalid DNS format, MUST be IPv4"
    ip_promote;
  else
    confirmation;
  fi
}

confirmation() {
  echo
  log info "Confirmation"
  
  while true ; do
    echo -e "\t$(color "Interface:" "fg-cyan") $IFACE"
    echo -e "\t$(color "IP:" "fg-cyan") $IP_CIDR"
    echo -e "\t$(color "Gateway:" "fg-cyan") $GATEWAY"
    echo -e "\t$(color "DNS:" "fg-cyan") $DNS"
    echo -ne "\t$(color "Is this correct?" "fg-yellow") "
    read -p "(y/N):" -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]] ; then
      echo
      log info "Applying IP configuration..."
      break;
    else
      ip_promote;
    fi
  done
}
