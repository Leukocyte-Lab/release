#!/usr/bin/env bash

about() {
  printf '%20s ' "$(color "Resource" "bold fg-white --bash")"
  echo -e "$(color "Info" "bold fg-white --bash")"
  printf -- '-%.0s' {1..10}
  echo -ne " "
  printf -- '-%.0s' {1..50}
  echo

  printf '%20s ' "$(color "CPU" "fg-blue --bash")"
  echo -e "$(color "$(_info_cpu_cores)" "bold fg-white") cores - $(color "$(_info_cpu_name)" "bold fg-white")"

  printf '%20s ' "$(color "Memory" "fg-blue --bash")"
  echo -e "$(color "$(_info_memory)" "bold fg-white")"

  printf '%20s ' "$(color "Disk" "fg-blue --bash")"
  echo -e "$(color "$(_info_disk)" "bold fg-white") - $(color "$(_info_disk_usage)" "bold fg-white") used"

  printf '%20s ' "$(color "OS" "fg-blue --bash")"
  echo -e "$(color "$(_info_os)" "bold fg-white") (Kernel $(color "$(_info_kernel)" "bold fg-white"))"

  printf '%20s ' "$(color "IP" "fg-blue --bash")"
  echo -e "$(color "$(_info_ip)" "bold fg-white")"

  printf '%20s ' "$(color "Hostname" "fg-blue --bash")"
  echo -e "$(color "$(_info_hostname)" "bold fg-white")"

  printf '%20s ' "$(color "Clock" "fg-blue --bash")"
  echo -e "$(color "$(_info_clock)" "bold fg-white") ($(color "$(_info_timezone)" "bold fg-white"))"
}
