#!/usr/bin/env bash

# shellcheck disable=SC2034
description_update="Check for updates and update the VM Utility"

update() {
  UTILITY_ARCHIVE="utility.tgz"

  if [[ "$1" == "--startup-check" ]]; then
    update_check -q
  elif [[ "$1" == "v"*"."*"."* ]]; then
    update_apply "$1"
  else
    update_check
  fi
}

update_check() {
  if [[ $1 != "-q" ]]; then
    echo
    echo -ne "$(log info "Checking for updates...")"
    NEW_UTILITY_VERSION="$(curl -fsL --connect-timeout 3 "https://$RELEASE_CHANNEL_SERVER/vm-utility/latest/version")"
  else
    NEW_UTILITY_VERSION="$(curl -fsL --connect-timeout 3 "https://$RELEASE_CHANNEL_SERVER/vm-utility/latest/version")"
  fi

  if [[ -z $NEW_UTILITY_VERSION ]] || [[ "$NEW_UTILITY_VERSION" == "$UTILITY_VERSION" ]]; then
    if [[ $1 != "-q" ]]; then
      color "[DONE]" "bold fg-green"
      log info "The VM Utility is up to date!"
      return 0
    fi
  else
    log info "New VM Utility is available: $NEW_UTILITY_VERSION"
    echo -ne "\t$(color "Do you want to update the VM Utility now?" "fg-yellow") "
    read -p "[y/N]: " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
      update_apply "$NEW_UTILITY_VERSION"
    fi
  fi
}

update_apply() {
  UTILITY_VERSION="${VERSION:-$1}"
  UTILITY_DOWNLOAD_LINK="https://$RELEASE_CHANNEL_SERVER/vm-utility/$UTILITY_VERSION/utility.tgz"
  echo
  if wget -q --show-progress -O utility.tgz "$UTILITY_DOWNLOAD_LINK"; then
    log success "VM Utility downloaded successfully!"
  else
    log error "Failed to download VM Utility version: $UTILITY_VERSION"
    exit 1
  fi

  echo -ne "$(log info "Updating VM Utility...")"
  if tar zxf utility.tgz -C "$DIR_PATH"; then
    color "[DONE]" "bold fg-green"
  else
    log error "Failed to extract VM Utility"
    return 1
  fi

  rm -f utility.tgz

  log info "Applying VM Utility..."
  echo
  # shellcheck disable=SC1091
  if source "$DIR_PATH/shell.sh"; then
    log success "VM Utility has been updated successfully!"
  else
    log error "Failed to update VM Utility"
    return 1
  fi
}
