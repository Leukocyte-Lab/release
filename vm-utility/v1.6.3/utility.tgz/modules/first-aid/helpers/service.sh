#!/usr/bin/env bash

first_aid_service() {
  local failed_services=()
  local services=()

  if [[ -n "$SYSTEM_VERSION" ]] && version_lt "$SYSTEM_VERSION" "v3.10.0"; then
    services=(
      "sts/db"
      "sts/rabbitmq"
      "sts/redis-master"
      "deploy/minio"
      "deploy/controller"
      "deploy/captain"
      "deploy/report"
      "deploy/ui"
      "deploy/postfix"
    )
  else
    services=(
      "sts/db"
      "sts/rabbitmq"
      "sts/redis-master"
      "deploy/minio"
      "deploy/controller"
      "deploy/action-loop"
      "deploy/captain"
      "deploy/report"
      "deploy/ui"
      "deploy/postfix"
    )
  fi

  local sys_services=(
    "deploy/coredns"
    "deploy/metrics-server"
    "deploy/local-path-provisioner"
    "deploy/traefik"
  )

  first_aid_service_liveness_check "k3s critical" "kube-system" "${sys_services[@]}";
  first_aid_service_liveness_check "$BRAND" "$NAMESPACE" "${services[@]}";

  if [[ $1 != '--dry-run' ]] && [[ $1 != '--force-restart-service' ]] && [[ ${#failed_services[@]} -gt 0 ]]; then
    log info "Trying to recover failed services..."

    first_aid_service_recovery;
  elif [[ $1 == '--force-restart-service' ]]; then
    log warn "User requested to force restart all services"
    log info "Force restarting all services..."

    for service in "${services[@]}"; do
      failed_services+=("$NAMESPACE:$service")
    done
    for service in "${sys_services[@]}"; do
      failed_services+=("kube-system:$service")
    done

    first_aid_service_recovery;
  elif [[ $1 == '--dry-run' ]] && [[ ${#failed_services[@]} -gt 0 ]]; then
    first_aid_print_verbose;
  elif [[ $1 == '--verbose' ]]; then
    first_aid_print_verbose;
  fi
}

first_aid_service_liveness_check() {
  echo
  local target="$1"; shift
  local service_ns="$1"; shift
  local _services=("$@")

  log info "Running $target services liveness check..."

  for service in "${_services[@]}"; do
    printf '%-40s ' "$(color "$service" "fg-white --bash")"
    if kubectl -n "$service_ns" rollout status "$service" --revision=0 --timeout 1s >/dev/null 2>&1; then
      color "[RUNNING]" "bold fg-green"
    else
      color "[FAILED]" "bold fg-red"
      failed_services+=("$service_ns:$service")
    fi
  done

  if [[ ${#failed_services[@]} -gt 0 ]]; then
    log error "Some services are failed with reasons"
    echo
  else
    log success "All $target services are up & running"
    echo
  fi
}

first_aid_service_recovery() {
  echo
  local error_found=0
  for service in "${failed_services[@]}"; do
    local ns="${service%%:*}"
    local name="${service##*:}"
    printf '%-40s ' "$(color "$name" "fg-white --bash")"
    if kubectl -n "$ns" rollout restart "$name" >/dev/null 2>&1; then
      color "[RESTARTED]" "bold fg-yellow"
    else
      color "[FAILED]" "bold fg-red"
      error_found=1
    fi
  done
  echo

  echo -ne "$(log info "Waiting for k3s critical services to be up & running...")"
  if kubectl -n kube-system rollout status deploy --timeout 60s >/dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    color "[FAILED]" "bold fg-red"
    log error "Failed to recover k3s critical services"
    error_found=1
  fi

  echo -ne "$(log info "Waiting for $BRAND services to be up & running...")"
  if kubectl -n "$NAMESPACE" rollout status "${services[@]}" --timeout 60s >/dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    color "[FAILED]" "bold fg-red"
    log error "Failed to recover $BRAND services"
    error_found=1
  fi

  if [[ $error_found -eq 0 ]]; then
    log success "All services are up & running"
  else
    log error "Some services failed to recover"
    log error "Please check the logs for more information"
    first_aid_print_verbose;
    return 1;
  fi
}

first_aid_print_verbose() {
  log info "Printing Node information..."
  kubectl get nodes -o wide
  echo

  log info "Printing all pods in all namespaces..."
  kubectl get pods -A -o wide
  echo
  
  log info "Printing last 25 events in all namespaces..."
  kubectl get events -A --sort-by='.metadata.creationTimestamp' | tail -n 25
  echo
}