#!/usr/bin/env bash

first_aid_sys() {
  local errors_found=0
  local warnings_found=0

  log info "Gathering system information..."
  echo
  about;
  
  echo
  log info "Performing system checks..."
  first_aid_sys_ip_check;
  first_aid_sys_k3s_check;
  first_aid_sys_disk_check;
  echo

  if [[ $errors_found -gt 0 ]]; then
    log error "System checks failed with $errors_found errors and $warnings_found warnings"
    log error "Please check the logs for more information"
    echo
    return 1
  elif [[ $warnings_found -gt 0 ]]; then
    log warn "System checks completed with $warnings_found warnings"
    log warn "Please check the logs for more information"
    echo
  else
    log success "System checks completed successfully"
    echo
  fi
}

first_aid_sys_ip_check() {
  echo -ne "$(log info "Performing IP address check...")"

  if [[ "$(_info_ip)" == "Unknown" ]] || [[ "$(_info_ip)" == "::1" ]] || [[ "$(_info_ip)" == "127."* ]] || [[ "$(_info_ip)" == "10.42."* ]] || [[ "$(_info_ip)" == "0."* ]] || [[ -z "$(_info_ip)" ]]; then
    color "[FAIL]" "bold fg-red"
    log error "No IP address found"
    errors_found=$((errors_found + 1))
  elif [[ "$(_info_ip)" == "169.254." ]]; then
    color "[WARN]" "bold fg-yellow"
    log warn "Link-local address found"
    log warn "This may indicate a network configuration issue, which may happen if the system is unable to obtain an IP address from a DHCP server"
    log warn "Please check your network configuration if this is not expected"
    warnings_found=$((warnings_found + 1))
  else
    color "[PASS]" "bold fg-green"
  fi
}

first_aid_sys_k3s_check() {
  echo -ne "$(log info "Performing K3s check...")"
  if kubectl get nodes >/dev/null 2>&1; then
    color "[PASS]" "bold fg-green"
  else
    color "[FAIL]" "bold fg-red"
    log error "K3s is not running"
    log error "Please check the system logs for more information"
    log info "You can check the logs with the command: $(color "sudo journalctl -xeu k3s" "bold fg-blue")"
    errors_found=$((errors_found + 1))
  fi
}

first_aid_sys_disk_check() {
  echo -ne "$(log info "Performing disk usage check...")"
  local DISK_USAGE
  DISK_USAGE="$(_info_disk_usage | sed 's/%//')"
  if [[ "$DISK_USAGE" -gt 90 ]]; then
    color "[FAIL]" "bold fg-red"
    log error "Disk usage is above 90%"
    log error "System might fail to operate properly"
    log error "Please consider cleaning up unused files or increasing disk space"
    return 1
  elif [[ "$DISK_USAGE" -gt 80 ]]; then
    color "[WARN]" "bold fg-yellow"
    log warn "Disk usage is above 80%"
    log warn "System might be unstable or slow"
    log warn "Please consider cleaning up unused files or increasing disk space"
  else
    color "[PASS]" "bold fg-green"
  fi
}
