#!/usr/bin/env bash

# shellcheck disable=SC2034
description_first_aid="Run first aid on the system"

alias first-aid="first_aid"

first_aid() {
  # shellcheck disable=SC1091
  source "$DIR_PATH/modules/first-aid/helpers/sys.sh"
  # shellcheck disable=SC1091
  source "$DIR_PATH/modules/first-aid/helpers/service.sh"

  if [[ "$1" == "-h" || "$1" == "--help" ]]; then
    first_aid_help
    return 0
  elif [[ "$1" == "--dry-run" ]] || [[ "$1" == "--force-restart-service" ]] || [[ "$1" == "--verbose" ]] || [[ -z "$1" ]]; then
    first_aid_sys;
    first_aid_service "$1";
    benchmark;
    check-network;
  else
    echo -e "$(color "Invalid option: $1" "bold fg-red")"
    echo
    first_aid_help
    return 1
  fi
}

first_aid_help() {
  echo
  echo -e "Usage: $(color "first-aid" "bold fg-yellow") $(color "(options)" "bold fg-green")"
  echo
  echo -e "$(color "Options" "bold fg-white")"
  echo -e "  $(color "first-aid" "bold fg-yellow") $(color "-h, --help" "bold fg-green") \t Show help message for the command"
  echo -e "  $(color "first-aid" "bold fg-yellow") $(color "--dry-run" "bold fg-green") \t Run first aid without applying any fixture or changes"
  echo -e "  $(color "first-aid" "bold fg-yellow") $(color "--verbose" "bold fg-green") \t Run first aid with verbose output"
  echo -e "  $(color "first-aid" "bold fg-yellow") $(color "--force-restart-service" "bold fg-green") \t Run first aid with force restart of all services"
  echo
}
