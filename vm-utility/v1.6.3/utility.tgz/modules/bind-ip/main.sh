#!/usr/bin/env bash

# shellcheck disable=SC2034
description_bind_ip="Bind static IP for the required services"

alias bind-ip="bind_ip"

bind_ip() {
  if [[ "$1" == "-a" || "$1" == "--apply" ]]; then
    bind_ip_apply
  elif [[ "$1" == "-r" || "$1" == "--remove" ]]; then
    bind_ip_remove
  else
    bind_ip_help
  fi
}

bind_ip_help() {
  echo
  echo -e "Usage: $(color "bind-ip" "bold fg-yellow") $(color "(options)" "bold fg-green")"
  echo
  echo -e "$(color "Options" "bold fg-white")"
  echo -e "  $(color "bind-ip" "bold fg-yellow") $(color "-a, --apply" "bold fg-green") \t Apply static IP bind for the required services"
  echo -e "  $(color "bind-ip" "bold fg-yellow") $(color "-r, --remove" "bold fg-green") \t Remove static IP bind for the required services"
  echo -e "  $(color "bind-ip" "bold fg-yellow") $(color "-h, --help" "bold fg-green") \t Show help message for the command"
  echo
}

bind_ip_apply() {
  # shellcheck disable=SC1091
  source "$DIR_PATH/modules/bind-ip/apply.sh"
}

bind_ip_remove() {
  # shellcheck disable=SC1091
  source "$DIR_PATH/modules/bind-ip/remove.sh"
}
