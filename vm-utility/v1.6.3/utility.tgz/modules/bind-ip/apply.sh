#!/usr/bin/env bash

cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: ConfigMap
metadata:
  name: coredns-custom # this is the name of the configmap you can overwrite with your changes
  namespace: kube-system
data:
  custom.server: |
    $LICENSE_SERVER $REGISTRY_SERVER $RELEASE_CHANNEL_SERVER $ARTIFACT_SERVER $POINT_SYS_SERVER $CHART_SERVER {
      hosts {
       $LICENSE_SERVER_IP         $LICENSE_SERVER
       $REGISTRY_SERVER_IP        $REGISTRY_SERVER
       $RELEASE_CHANNEL_SERVER_IP $RELEASE_CHANNEL_SERVER
       $ARTIFACT_SERVER_IP        $ARTIFACT_SERVER
       $POINT_SYS_SERVER_IP       $POINT_SYS_SERVER
       $CHART_SERVER_IP           $CHART_SERVER
       fallthrough
      }
    }
EOF

kubectl -n kube-system rollout restart deploy/coredns

log info "CoreDNS custom configuration applied"

echo -ne "$(log info "Waiting for CoreDNS to be ready...")"
sleep 10
if kubectl -n kube-system wait --for=condition=ready pods -l k8s-app=kube-dns --timeout 120s >/dev/null 2>&1; then
  color "[DONE]" "bold fg-green"
else
  log error "CoreDNS is not ready";
  log error "IP configuration failed";
  return 1
fi

log info "Checking cluster network..."

kubectl run -n "$NAMESPACE" -it --rm check-network \
    --overrides='{ "spec": { "imagePullSecrets": [{"name": "lkc-registry"}] } }' \
    -it --rm \
    check-network \
    --overrides='{ "spec": { "imagePullSecrets": [{"name": "lkc-registry"}] } }' \
    --image="$REGISTRY_SERVER/leukocyte-lab/check-network:latest" \
    --env IN_CLUSTER=true \
    --env LICENSE_SERVER="$LICENSE_SERVER" \
    --env REGISTRY_SERVER="$REGISTRY_SERVER" \
    --env RELEASE_CHANNEL_SERVER="$RELEASE_CHANNEL_SERVER" \
    --env ARTIFACT_SERVER="$ARTIFACT_SERVER" \
    --env POINT_SYS_SERVER="$POINT_SYS_SERVER" \
    --env CHART_SERVER="$CHART_SERVER" \
    --restart=Never

# shellcheck disable=SC2181
if [ $? -eq 0 ]; then
  log success "Cluster network check done!"
else
  log error "Cluster network check failed"
  return 1
fi
