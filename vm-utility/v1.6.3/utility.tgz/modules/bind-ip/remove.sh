#!/usr/bin/env bash

kubectl delete -n kube-system cm/coredns-custom
kubectl -n kube-system rollout restart deploy/coredns

log info "CoreDNS custom configuration removed"
