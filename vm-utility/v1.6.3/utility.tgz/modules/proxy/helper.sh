#!/usr/bin/env bash

promote() {
  log info "User asked to modify proxy configuration"

  NO_PROXY_DEFAULT=127.0.0.0/8,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16;

  read -rp "$(echo -ne "\t$(color "Enter HTTP Proxy Server:\n  (URL, ex: http://user:password@proxy.example.com:1080): " "fg-cyan")")" HTTP_PROXY
  read -rp "$(echo -ne "\t$(color "Enter No Proxy list, seperate by comma ',':\n (default: $NO_PROXY_DEFAULT): ")")" NO_PROXY_PROMPT

  NO_PROXY="${NO_PROXY_PROMPT:-$NO_PROXY_DEFAULT}"

  export HTTP_PROXY;
  export NO_PROXY;

  confirmation;
}

confirmation() {
  echo
  log info "Confirmation"
  
  while true ; do
    echo -e "\t$(color "HTTP Proxy Server:" "fg-cyan") $HTTP_PROXY"
    echo -e "\t$(color "No Proxies:" "fg-cyan") $NO_PROXY"
    echo -ne "\t$(color "Is this correct?" "fg-yellow") "
    read -p "(y/N):" -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]] ; then
      log info "Applying Proxy configuration..."
      apply;
      break;
    else
      promote;
    fi
  done
}

options() {
  log info "Choose what you want to do"
  
  while true ; do
    color "- (N) Setup proxy / Modify existed proxy config (default options)" "fg-blue"
    color "- (R) Remove proxy config" "fg-blue"
    color "- (Q) Quit" "fg-blue"
    echo -ne "$(color "Enter one options to continue: " "bold fg-blue")"
    read -p "(N/r/q):" -n 1 -r
    
    echo
    if [[ $REPLY =~ ^[Rr]$ ]] ; then
      remove;
      break;
    elif [[ $REPLY =~ ^[Nn]$ ]] || [[ $REPLY = "" ]] ; then
      promote;
      break;
    elif [[ $REPLY =~ ^[Qq]$ ]] ; then
      log info "Proxy configuration skipped"
      return 0;
    else
      log error "Invalid option"
    fi
  done
}