#!/usr/bin/env bash

# shellcheck disable=SC2034
description_proxy="Configure Proxy for the VM"

proxy() {
  source "$DIR_PATH/modules/proxy/helper.sh"
  source "$DIR_PATH/modules/proxy/apply.sh"
  source "$DIR_PATH/modules/proxy/remove.sh"

  echo
  check_if_root
  options
  echo
}

apply() {
  apply_proxy_k3s;

  echo -ne "$(log info "Waiting for k3s to be ready...")"
  if kubectl wait --for=condition=ready --timeout=60s node/"$(hostname)" > /dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    log error "Node is not ready"
    log error "Proxy configuration failed"
    return 1
  fi

  apply_proxy_app;
  
  echo -ne "$(log info "Waiting for system performing Helm operation on $BRAND...")"
  if kubectl -n kube-system wait --for=condition=complete "jobs/helm-install-$CHART_NAME" --timeout 300s > /dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    log error "Failed to apply $BRAND HelmChart modifications"
    log error "Proxy configuration failed"
    return 1
  fi

  echo -ne "$(log info "Waiting for $BRAND to be ready...")"
  if kubectl -n "$NAMESPACE" wait --for=condition=ready pods -l app=captain --timeout 300s > /dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    log error "$BRAND is not ready"
    log error "Proxy configuration failed"
    return 1
  fi

  log success "Proxy configuration applied successfully"
}

remove() {
  remove_proxy_k3s;

  echo -ne "$(log info "Waiting for k3s to be ready...")"
  if kubectl wait --for=condition=ready --timeout=60s node/"$(hostname)" > /dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    log error "Node is not ready"
    log error "Proxy configuration failed"
    return 1
  fi

  remove_proxy_app;

  echo -ne "$(log info "Waiting for system performing Helm operation on $BRAND...")"
  if kubectl -n kube-system wait --for=condition=complete "jobs/helm-install-$CHART_NAME" --timeout 300s > /dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    log error "Failed to apply $BRAND HelmChart modifications"
    log error "Proxy configuration failed"
    return 1
  fi

  echo -ne "$(log info "Waiting for $BRAND to be ready...")"
  if kubectl -n "$NAMESPACE" wait --for=condition=ready pods -l app=captain --timeout 300s > /dev/null 2>&1; then
    color "[DONE]" "bold fg-green"
  else
    log error "$BRAND is not ready"
    log error "Proxy configuration failed"
    return 1
  fi

  log success "Proxy configuration removed successfully"
}
