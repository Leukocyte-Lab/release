#!/usr/bin/env bash

remove_proxy_app() {
  log info "Removing Proxy from $BRAND..."

  kubectl -n kube-system patch "HelmChart/$CHART_NAME" --type='json' -p="[
    {\"op\":\"remove\",\"path\":\"/spec/set/global.proxy.enabled\"},
    {\"op\":\"remove\",\"path\":\"/spec/set/global.proxy.httpProxy\"},
    {\"op\":\"remove\",\"path\":\"/spec/set/global.proxy.httpsProxy\"},
    {\"op\":\"remove\",\"path\":\"/spec/set/global.proxy.noProxy\"}
  ]"
}

remove_proxy_k3s() {
  log info "Removing Proxy from k3s..."
  log info "Backup configuration: "
  sudo cp /etc/systemd/system/k3s.service.env "$DIR_PATH/k3s.service.env.bak"

  log info "  /etc/systemd/system/k3s.service.env -> $DIR_PATH/k3s.service.env.bak"

  sudo sed -i '/HTTP_PROXY/d' /etc/systemd/system/k3s.service.env
  sudo sed -i '/HTTPS_PROXY/d' /etc/systemd/system/k3s.service.env
  sudo sed -i '/NO_PROXY/d' /etc/systemd/system/k3s.service.env

  sudo chmod 644 /etc/systemd/system/k3s.service.env

  sudo systemctl restart k3s.service
}
