#!/usr/bin/env bash

apply_proxy_app() {
  log info "Applying Proxy on $BRAND..."

  kubectl -n kube-system patch "HelmChart/$CHART_NAME" --type='json' -p="[
    {\"op\":\"replace\",\"path\":\"/spec/set/global.proxy.enabled\",\"value\":\"true\"},
    {\"op\":\"replace\",\"path\":\"/spec/set/global.proxy.httpProxy\",\"value\":\"$HTTP_PROXY\"},
    {\"op\":\"replace\",\"path\":\"/spec/set/global.proxy.httpsProxy\",\"value\":\"$HTTP_PROXY\"},
    {\"op\":\"replace\",\"path\":\"/spec/set/global.proxy.noProxy\",\"value\":\"$NO_PROXY\"}
  ]"
}

apply_proxy_k3s() {
  log info "Applying Proxy from k3s..."
  log info "Backup configuration: "
  sudo cp /etc/systemd/system/k3s.service.env "$DIR_PATH/k3s.service.env.bak"

  log info "  /etc/systemd/system/k3s.service.env -> $DIR_PATH/k3s.service.env.bak"

  sudo sed -i '/HTTP_PROXY/d' /etc/systemd/system/k3s.service.env
  sudo sed -i '/HTTPS_PROXY/d' /etc/systemd/system/k3s.service.env
  sudo sed -i '/NO_PROXY/d' /etc/systemd/system/k3s.service.env

  cat <<EOF | sudo tee -a /etc/systemd/system/k3s.service.env
HTTP_PROXY=$HTTP_PROXY
HTTPS_PROXY=$HTTP_PROXY
NO_PROXY=$NO_PROXY
EOF

  sudo chmod 644 /etc/systemd/system/k3s.service.env

  sudo systemctl restart k3s.service
}
