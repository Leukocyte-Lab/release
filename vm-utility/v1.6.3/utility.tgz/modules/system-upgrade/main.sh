#!/usr/bin/env bash

# shellcheck disable=SC2034
description_system_upgrade="$BRAND system upgrade tools"

alias system-upgrade="system_upgrade"

system_upgrade() {
  if [[ "$1" == "-h" || "$1" == "--help" ]]; then
    system_upgrade_help;
  else
    system_upgrade_cmd "$@";
  fi
}

system_upgrade_cmd() {
  local latest_chart_version;
  local latest_app_version;
  
  check_if_root;
  if [ $? -eq 1 ]; then
    echo
    return 1
  fi
  
  source "$DIR_PATH/modules/system-upgrade/helper.sh";

  if upgrade_precheck "$1"; then
    if ! backup; then
      if [[ "$1" == "-f" || "$1" == "--force" ]]; then
        log warning "Backup failed, but continuing with system upgrade due to force flag"
        confirmation;
      else
        log error "Backup failed, system upgrade aborted"
        return 1;
      fi
    else 
      confirmation;
    fi
  fi
}

system_upgrade_help() {
  echo
  echo -e "Usage: $(color "system-upgrade" "bold fg-yellow") $(color "(options)" "bold fg-green")"
  echo
  echo -e "$(color "Options" "bold fg-white")"
  echo -e "  $(color "system-upgrade" "bold fg-yellow") $(color "-f, --force" "bold fg-green") \t Force upgrade the system, ignoring the precheck"
  echo -e "  $(color "system-upgrade" "bold fg-yellow") $(color "-h, --help" "bold fg-green") \t Show help message for the command"
  echo
}
