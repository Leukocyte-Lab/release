#!/usr/bin/env bash

trim() {
  sed 's/^[ \t]*//;s/[ \t]*$//'
}

_info_cpu_name() {
  local CPU_INFO
  if command -v lscpu >/dev/null 2>&1; then
    CPU_INFO="$(lscpu | grep 'Model name' | awk -F ': ' '{print $2}')"
  elif command -v cat >/dev/null 2>&1; then
    CPU_INFO="$(grep 'model name' < /proc/cpuinfo | head -n 1 | awk -F ': ' '{print $2}')"
  else
    CPU_INFO="Unknown"
  fi

  echo "$CPU_INFO" | trim
}

_info_cpu_cores() {
  local CPU_CORES

  CPU_CORES="$(grep -c 'processor' < /proc/cpuinfo)"

  echo "$CPU_CORES" | trim
}

_info_memory() {
  if command -v lsmem >/dev/null 2>&1; then
    MEMORY_INFO="$(lsmem | grep 'Total online' | awk -F ': ' '{print $2}')"
  elif command -v cat >/dev/null 2>&1; then
    MEMORY_INFO="$(grep 'MemTotal' < /proc/meminfo | awk '{print $2}')"
  elif command -v free >/dev/null 2>&1; then
    MEMORY_INFO="$(free -h | grep 'Mem' | awk '{print $2}')"
  else
    MEMORY_INFO="Unknown"
  fi

  echo "$MEMORY_INFO" | trim
}

_info_disk() {
  DISK_INFO="$(df -h | grep '/$' | awk '{print $2}')"

  echo "$DISK_INFO" | trim
}

_info_disk_usage() {
  DISK_USAGE="$(df -h | grep '/$' | awk '{print $5}')"

  echo "$DISK_USAGE" | trim
}

_info_os() {
  local OS_INFO
  OS_INFO="$(grep 'DISTRIB_DESCRIPTION' < /etc/lsb-release | awk -F '=' '{print $2}' | tr -d '"')"

  echo "$OS_INFO" | trim
}

_info_kernel() {
  local KERNEL_INFO
  if command -v uname >/dev/null 2>&1; then
    KERNEL_INFO="$(uname -r)"
  else
    KERNEL_INFO="Unknown"
  fi

  echo "$KERNEL_INFO" | trim
}

_info_uptime() {
  local UPTIME_INFO
  if command -v uptime >/dev/null 2>&1; then
    UPTIME_INFO="$(uptime -p | sed 's/up //')"
  else
    UPTIME_INFO="Unknown"
  fi

  echo "$UPTIME_INFO" | trim
}

_info_hostname() {
  local HOSTNAME_INFO
  if command -v hostname >/dev/null 2>&1; then
    HOSTNAME_INFO="$(hostname)"
  else
    HOSTNAME_INFO="Unknown"
  fi

  echo "$HOSTNAME_INFO" | trim
}

_info_ip() {
  local IP_INFO
  if command -v hostname >/dev/null 2>&1; then
    IP_INFO="$(hostname -I | awk '{print $1}')"
  else
    IP_INFO="Unknown"
  fi

  echo "$IP_INFO" | trim
}

_info_k3s() {
  local K3S_INFO
  if command -v k3s >/dev/null 2>&1; then
    K3S_INFO="$(k3s --version | grep k3s | awk '{print $3}')"
  else
    K3S_INFO="Unknown"
  fi

  echo "$K3S_INFO" | trim
}

_info_clock() {
  local CLOCK_INFO
  if command -v date >/dev/null 2>&1; then
    CLOCK_INFO="$(date +'%Y-%m-%d %H:%M:%S')"
  else
    CLOCK_INFO="Unknown"
  fi

  echo "$CLOCK_INFO" | trim
}

_info_timezone() {
  local TIMEZONE_INFO
  if command -v date >/dev/null 2>&1; then
    TIMEZONE_INFO="$(date +'%Z')"
  else
    TIMEZONE_INFO="Unknown"
  fi

  echo "$TIMEZONE_INFO" | trim
}
