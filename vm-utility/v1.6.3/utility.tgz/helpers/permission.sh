#!/usr/bin/env bash

check_if_root() {
  if [ "$EUID" -ne 0 ]; then
    if ! sudo -n true 2>/dev/null; then
      # prompt user for password
      log warning "This command must be run as root, enter your password to continue."
      if ! sudo -s 'exit'; then
        log error "User authentication failed, exiting..."
        return 1
      else
        log success "Authenticated"
      fi
    fi
  fi
}
