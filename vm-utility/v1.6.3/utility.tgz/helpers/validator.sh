#!/bin/bash

_validator_is_valid_ipv4() {
    local ip=$1
    # Regular expression to check for the format X.X.X.X where X is 1-3 digits
    if [[ $ip =~ ^([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})$ ]]; then
        # Extract octets
        local o1=${BASH_REMATCH[1]}
        local o2=${BASH_REMATCH[2]}
        local o3=${BASH_REMATCH[3]}
        local o4=${BASH_REMATCH[4]}

        # Check if each octet is within the valid range (0-255)
        if (( o1 >= 0 && o1 <= 255 )) && \
           (( o2 >= 0 && o2 <= 255 )) && \
           (( o3 >= 0 && o3 <= 255 )) && \
           (( o4 >= 0 && o4 <= 255 )); then
            return 0 # Valid IPv4
        else
            return 1 # Invalid octet range
        fi
    else
        return 1 # Invalid format
    fi
}

_validator_is_valid_cidr() {
    local cidr=$1
    # Split CIDR into IP and prefix
    IFS='/' read -r ip prefix <<< "$cidr"

    # Validate IP part
    _validator_is_valid_ipv4 "$ip" || return 1

    # Validate prefix part
    if ! [[ $prefix =~ ^[0-9]+$ ]] || (( prefix < 0 || prefix > 32 )); then
        return 1 # Invalid prefix
    fi

    return 0 # Valid CIDR
}
