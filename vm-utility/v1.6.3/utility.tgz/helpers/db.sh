#!/bin/bash

_db_get_secret () {
  kubectl -n "$NAMESPACE" get secret/agh-db-secret -o=jsonpath='{.data.postgres-password}' | base64 -d
}

_db_shell () {
  secret="$(_db_get_secret)";
  kubectl -n "$NAMESPACE" exec -it sts/db -- bash -c \
    ". /opt/bitnami/scripts/libpostgresql.sh && \\
      postgresql_enable_nss_wrapper && \\
      PGPASSWORD=$secret \\
      psql -E $*
    "
}

_db () {
  db_name="$1";
  query="$2";
  secret="$(_db_get_secret)";

  kubectl -n "$NAMESPACE" exec -t sts/db -- bash -c \
    ". /opt/bitnami/scripts/libpostgresql.sh && \\
      postgresql_enable_nss_wrapper && \\
      PGPASSWORD=$secret \\
      psql -v ON_ERROR_STOP=1 -X -d $db_name -t -A -q <<'EOF'
$query
EOF
    "
}
